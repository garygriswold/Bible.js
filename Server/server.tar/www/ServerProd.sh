#!/bin/sh
node Router.js > server.log &

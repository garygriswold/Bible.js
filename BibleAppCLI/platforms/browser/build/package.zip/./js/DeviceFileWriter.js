/**
 * This is the cordova implementation of LocalFileWriter.  There is also a
 * Node.js implementation
 */
function LocalFileWriter(location) {
    this.location = location;
    Object.seal(this);
}
LocalFileWriter.prototype.createDirectory = function(filepath, callback) {

};
LocalFileWriter.prototype.writeTextFile = function(filename, data, callback) {
    deviceFileSystem.getPersistent(function(fileSystem) {
        console.log('inside get file');
        var options = {create: true, exclusive: true};
        fileSystem.root.getFile(filename, options, onGetFileSuccess, onGetFileError);
        console.log('filesystempath', fileSystem.root.nativeURL);
    });
    function onGetFileSuccess(fileEntry) {
        console.log('ongetfile success', JSON.stringify(fileEntry));
        fileEntry.createWriter(onGetWriterSuccess, onGetWriterError);
    }
    function onGetFileError(error) {
        returnError(error, 'getFile');
    }
    function onGetWriterSuccess(writer) {
        console.log('got writer', JSON.stringify(writer));
        writer.onabort = function(event) {
            console.log('write aborted');
            callback(event);
        };
        writer.onwritestart = function(event) {
            console.log('write started');
        };
        writer.onwrite = function(event) {
            console.log('write happened');
            callback(event);
        };
        writer.onwriteend = function(event) {
            console.log('write ended');
        };
        writer.onerror = function(error) {
            returnError(error, 'write');
        };
        writer.write(data);
    }
    function onGetWriterError(error) {
        returnError(error, 'getWriter');
    }
    function returnError(error, source) {
        error.source = source;
        error.message = deviceFileError.message(error);
        console.log('FileWriter Error', error.source, error.code, error.message);
        callback(error);
    }
};

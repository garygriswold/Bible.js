/**
 * This class only contains information about the errors
 * that can occur when using Cordova FileReader, FileWriter
 * and related classes.
 */
var deviceFileError = {
    message: function(error) {
        if (error === null) return('error-null');
        if (error.code === null) return('error.code-null');
        switch(error.code) {
            case FileError.NOT_FOUND_ERR:               // = 1;
                return('not-found-error');
            case FileError.SECURITY_ERR:                // = 2;
                return('security-error');
            case FileError.ABORT_ERR:                   // = 3;
                return('abort-error');
            case FileError.NOT_READABLE_ERR:            // = 4;
                return('not-readable-error');
            case FileError.ENCODING_ERR:                // = 5;
                return('encoding-error');
            case FileError.NO_MODIFICATION_ALLOWED_ERR: // = 6;
                return('no-modification-allowed-error');
            case FileError.INVALID_STATE_ERR:           // = 7;
                return('invalid-state-error');
            case FileError.SYNTAX_ERR:                  // = 8;
                return('syntax-error');
            case FileError.INVALID_MODIFICATION_ERR:    // = 9;
                return('invalid-modification-error');
            case FileError.QUOTA_EXCEEDED_ERR:          // = 10;
                return('quota-exceeded-error');
            case FileError.TYPE_MISMATCH_ERR:           // = 11;
                return('type-mismatch-error');
            case FileError.PATH_EXISTS_ERR:             // = 12;
                return('path-exists-error');
            default:
                return('unknown-error');
        }
    }
}
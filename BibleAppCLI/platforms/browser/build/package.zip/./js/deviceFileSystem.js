/**
 * This class holds the persistent file location
 */
var biblePersistentFileSystem = undefined; // Global variable

var deviceFileSystem = {
	getPersistent: function(callback) {
        if (biblePersistentFileSystem) {
            console.log('immediate callback');
            callback(biblePersistentFileSystem);
        } else {
            window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, onSuccess, onError);
        }
        function onSuccess(fs) {
            biblePersistentFileSystem = fs;
            callback(biblePersistentFileSystem);
        }
        function onError(err) {
            console.log('DeviceFileSystem.getPersistent', err);
            callback(null);
        }
    }
}
 /*
function FileReader(location) {
	this.location = '';
	this.filepath = '';
	this.successCallback = '';
	this.failureCallback = '';
	Object.seal(this);
}
FileReader.prototype.fileExists = function(filepath, callback) {
	var fullPath = FILE_ROOTS[this.location] + filepath;
	//console.log('checking fullpath', fullPath);
	this.fs.stat(fullPath, function(err, stat) {
		if (err) {
			err.filepath = filepath;
			callback(err);
		} else {
			callback(stat);
		}
	});
};
FileReader.prototype.readDirectory = function(filepath, callback) {
	var fullPath = FILE_ROOTS[this.location] + filepath;
	//console.log('read directory ', fullPath);
	this.fs.readdir(fullPath, function(err, data) {
		if (err) {
			err.filepath = filepath;
			callback(err);
		} else {
			callback(data);
		}
	});
};
FileReader.prototype.readTextFile = function(filepath, callback) {
	var fullPath = FILE_ROOTS[this.location] + filepath;
	//console.log('read file ', fullPath);
	this.fs.readFile(fullPath, { encoding: 'utf8'}, function(err, data) {
		if (err) {
			err.filepath = filepath;
			callback(err);
		} else {
			callback(data);
		}
	});
};
*/
/*
FileReader.prototype.readTextFile = function(location, filepath, successCallback, failureCallback) {
	var bytes = 1024 * 1024 * 10;
	var filepath = this.filepath;
	window.requestFileSystem(LocalFileSystem.PERSISTENT, bytes, onAccessReqSuccess, onAccessError);

	function onAccessReqSuccess(fileSystem) {
		window.alert('name: ' + fileSystem.root.name);
		window.alert('root: ' + fileSystem.root.fullPath);
		window.alert('native: ' + fileSystem.root.nativeURL);
		window.alert('inside access success ' + bytes);
		console.log('inside access success reading: ' + filepath);

		fileSystem.root.getFile(filepath, { create:false }, onGetFileSuccess, onGetFileError);

		/*function onWriteFileSuccess(file) {
			window.alert('created file ' + file.name);
			file.createWriter(onSuccess2, onError2);

			function onSuccess2(writer) {
				writer.onabort = function(e) {
					console.log("Write aborted");
				};
				writer.onwritestart = function(e) {
					console.log("Write start");
				};
				writer.onwrite = function(e) {
					console.log("Write completed");
				};
				writer.onwriteend = function(e) {
					console.log("Write end");
				};
				writer.onerror = function(e) {
					console.error("Write error");
					console.error(JSON.stringify(e));
				};
				writer.write("This file created Example 10.1");
			};
			function onError2(err) {
				window.alert('write err ' + err.code);
			};
		};
		function onWriteFileError(err) {
			window.alert('inside write file err ' + err.code);
		};
		function onGetFileSuccess(file) {
			//window.alert('fullpath ' + file.fullPath);
			//window.alert('isfile ' + file.isFile);
			//window.alert('url ' + file.nativeURL);

			file.getMetadata(onMetaDataSuccess, onMetaDataError);
			function onMetaDataSuccess(metadata) {
				//window.alert(JSON.stringify(metadata));
			};
			function onMetaDataError(err) {
				//window.alert(JSON.stringify(err));
			};

			var reader = new FileReader();
			var keys = Object.keys(reader);
			//window.alert(keys);
			for (var i=0; i<keys.length; i++) {
			//	window.alert(keys[i] + ': ' + reader[keys[i]]);
			}

			reader.onloadstart = function(evt) {
				//console.log('read file started');
				window.alert('start read ' + JSON.stringify(evt));
			};
			reader.onloadend = function(evt) {
				window.alert('done' + reader.result);
				console.log('read file ended');
				var result = JSON.stringify(evt);
				window.alert(result.substring(0,100));
				console.log(evt.target.result);
			};
			//reader.onloaderror = function(event) {
			//	console.log('error: ' + event.code);
			//};
			reader.readAsText(file, 'utf-8');
			//window.alert('after readAsText');
		};
		function onGetFileError(err) {
			window.alert('error ' + err.code);
		};
	};
	function onAccessError(err) {
		window.alert('inside access error');
	};
};
*/



/*
function FileWriter(location) {
	this.fs = require('fs');
	this.location = location;
	Object.freeze(this);
}
FileWriter.prototype.createDirectory = function(filepath, callback) {
	var fullPath = FILE_ROOTS[this.location] + filepath;
	this.fs.mkdir(fullPath, function(err) {
		if (err) {
			err.filepath = filepath;
			callback(err);
		} else {
			callback(filepath);
		}
	});
};
FileWriter.prototype.writeTextFile = function(filepath, data, callback) {
	var fullPath = FILE_ROOTS[this.location] + filepath;
	this.fs.writeFile(fullPath, data, { encoding: 'utf8'}, function(err) {
		if (err) {
			err.filepath = filepath;
			callback(err);
		} else {
			callback(filepath);
		}
	});
}
*/